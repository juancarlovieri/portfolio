$(".slick-carousel").slick({
  infinite: true,
  autoplay: true,
  speed: 300,
  autoplaySpeed: 4000,
  slidesToShow: 1,
  slidesToScroll: 1,
  dots: true
});
